
<style>
.example::-webkit-scrollbar {
  display: none;
}
        </style>
        <div class="col-md-3 left_col example" style="position:fixed;overflow-y: auto;max-height:200px;">
            <div class="left_col scroll-view">
                <div class="navbar nav_title text-center" style="border: 0;">
                    <!--<img src="../images/17ft.jpg" alt="logo" width="100" height="50" class="md">-->
                    <p style="color:#821920;font-size:22px;font-weight:bold;">17000ft Foundation</p>
                    <!--<img src="https://newone.advanceexcel.in/17kadmin/images/17ft.jpg" alt="logo" width="56" class="sm">-->
                </div>
                <div class="clearfix"></div>
                <!-- menu profile quick info -->
                <div class="profile clearfix text-center">                   
                    <div class="profile_info">
                        <h2> Admin Panel</h2>
                    </div>
                </div>
                <!-- /menu profile quick info -->
                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">
                        <ul class="nav side-menu">
                            <li><a href ="FLN-Assessment"><em class="fas fa-home"></em> Enrollment Form</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><em class="fa fa-bars"></em></a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                Admin
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <!--<li><a href="password.php"><em class="fa fa-key pull-right"></em> Change Password</a></li>-->
                                <li><a href="logout.php"><em class="fas fa-sign-out-alt pull-right"></em> Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->